//
//  Endpoints.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import Foundation

//MARK: EndPoints -:

enum Endponits {
    
    private var baseURL: String { return "https://jsonplaceholder.typicode.com" }
       
       case albums
       case photoWith(Int)

       
       private var fullPath: String {
           var endpoint:String
           
           switch self {
           case .photoWith(let id):
               endpoint = "/photos?albumId=\(id)"
           default:
               endpoint = "/\(String(describing: self))"
           }
           return baseURL + endpoint
       }
       
       var url: URL {
           guard let url = URL(string: fullPath) else {
               preconditionFailure("The url used in \(Endponits.self) is not valid")
           }
           return url
       }
   }
