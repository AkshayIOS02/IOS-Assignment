//
//  APIManager.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import Foundation
public class APIManager{
    
    // MARK: - Singleton instance
    public static let shared = APIManager()
    
    // MARK: - Properties
    public var authenticationToken : String? = nil
    public var customJsonDecoder : JSONDecoder? = nil
    
    // MARK: - Private initializer
    private init(){}
    
    // MARK: - Public functions
    public func request<T:Decodable>(request: Request, resultType: T.Type, completionHandler:@escaping(Result<T?, NetworkError>)-> Void){
        getData(requestUrl: request.url, resultType: resultType) { completionHandler($0)}
    }
    
    // MARK: - Private functions
    
    // Create a JSON decoder object
    private func createJsonDecoder() -> JSONDecoder{
        let decoder =  JSONDecoder()
        return decoder
    }
    
    // Create a URL request object with authentication token header
    private func createUrlRequest(requestUrl: URL) -> URLRequest{
        var urlRequest = URLRequest(url: requestUrl)
        if(authenticationToken != nil) {
            urlRequest.setValue(authenticationToken!, forHTTPHeaderField: "authorization")
        }
        return urlRequest
    }
    
    // Decode JSON response data to a Decodable object
    private func decodeJsonResponse<T: Decodable>(data: Data, responseType: T.Type) -> T?{
        let decoder = createJsonDecoder()
        do {
            return try decoder.decode(responseType, from: data)
        }catch let error {
            debugPrint("error while decoding JSON response =>\(error.localizedDescription)")
        }
        return nil
    }
    
    // MARK: - GET Api
    // Make a GET request with specified URL and result type
    private func getData<T:Decodable>(requestUrl: URL, resultType: T.Type, completionHandler:@escaping(Result<T?, NetworkError>)-> Void){
        var urlRequest = self.createUrlRequest(requestUrl: requestUrl)
        urlRequest.httpMethod = HttpMethods.get.rawValue
        
        performOperation(requestUrl: urlRequest, responseType: T.self) { (result) in
            completionHandler(result)
        }
    }
    
    // MARK: - Perform data task
    // Make a URL session data task and handle the response
    private func performOperation<T: Decodable>(requestUrl: URLRequest, responseType: T.Type, completionHandler:@escaping(Result<T?, NetworkError>) -> Void){
        URLSession.shared.dataTask(with: requestUrl) { (data, httpUrlResponse, error) in
            
            let statusCode = (httpUrlResponse as? HTTPURLResponse)?.statusCode
            if(error == nil && data != nil && data?.count != 0) {
                let response = self.decodeJsonResponse(data: data!, responseType: responseType)
                if(response != nil) {
                    completionHandler(.success(response))
                }else {
                    completionHandler(.failure(NetworkError(withServerResponse: data, forRequestUrl: requestUrl.url!, withHttpBody: requestUrl.httpBody, errorMessage: error.debugDescription, forStatusCode: statusCode!)))
                }
            }
            else {
                let networkError = NetworkError(withServerResponse: data, forRequestUrl: requestUrl.url!, withHttpBody: requestUrl.httpBody, errorMessage: error.debugDescription, forStatusCode: statusCode!)
                completionHandler(.failure(networkError))
            }
            
        }.resume()
    }
}
