//
//  Request.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import Foundation

//MARK: Request :- 
public struct Request {
    var url: URL
    var method: HttpMethods
    var requestBody: Data? = nil

    public init(withUrl url: URL, forHttpMethod method: HttpMethods, requestBody: Data? = nil) {
        self.url = url
        self.method = method
        self.requestBody = requestBody != nil ? requestBody : nil
    }
}
