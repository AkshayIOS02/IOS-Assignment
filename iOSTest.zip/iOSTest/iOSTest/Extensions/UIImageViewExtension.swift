//
//  UIImageViewExtension.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import UIKit
import SDWebImage

//MARK: UIImageDownloading
extension UIImageView {

    func setImageFromLink(_ link:String?, placeholder: String = "placeholder", contentMode: UIView.ContentMode = .scaleAspectFit) {
        self.image = UIImage(named: placeholder)

        guard
            let link = link, !link.isEmpty,
            let url = URL(string: link) else{
            return
        }
        
        self.sd_setImage(with: url,
                         placeholderImage: UIImage(named: placeholder))
    }
}


