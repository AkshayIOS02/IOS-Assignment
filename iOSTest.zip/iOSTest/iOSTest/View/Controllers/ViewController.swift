//
//  ViewController.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import UIKit

class ViewController: UIViewController{
    //IBOutlet
    @IBOutlet weak private var tableView: UITableView!
    
    // Instance of the view model class
    private let viewModel = HomeViewModel()
    
    //MARK: LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        dataSetup()
    }
    
    //MARK: This function is called every time the view layout changes
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        guard let headerView = tableView.tableHeaderView else {return}
        let size = headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
        if headerView.frame.size.height != size.height {
            headerView.frame.size.height = size.height
            tableView.tableHeaderView = headerView
            tableView.layoutIfNeeded()
        }
    }
    
    //MARK: Setup the initial data for the view controller
    private func dataSetup(){
        
        self.title = "Assignment"
        viewModel.albumAPICall {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
}

//MARK: Extension for the table view delegate and data source methods

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.albumArr?.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        return self.getTableHeaderView(title: viewModel.albumArr?[section].title ?? "")
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CollectionTableViewCell") as! CollectionTableViewCell
        viewModel.getPhotosForAlbum(model: viewModel.albumArr?[indexPath.row]) { listPhotoModel in
            DispatchQueue.main.async {
                cell.config(data: listPhotoModel,delegate: self, rowIndex: indexPath.row)
            }
            
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        guard let albumArrayCount = viewModel.albumArr?.count else {
            return
        }
        if indexPath.section == albumArrayCount - 1  {
            self.viewModel.increaseAlbumArray {
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    debugPrint("Vertical size increased")
                }
            }
        }
    }
    
    //MARK: GetTableHeaderView
    func getTableHeaderView(title: String) -> UIView{
        let labelHeight = estimatedLabelHeight(text: title, width: self.view.frame.width, font: UIFont.systemFont(ofSize: 20, weight: .bold))

        debugPrint(labelHeight)
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: labelHeight + 20))
        let titleLabel = UILabel(frame: CGRect(x: 8, y: 0, width: self.view.frame.width, height: labelHeight))
        headerView.addSubview(titleLabel)
        titleLabel.textColor = UIColor.black
        titleLabel.numberOfLines = 0
        titleLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        titleLabel.text = title
        headerView.backgroundColor = UIColor.white
        
        headerView.clipsToBounds = true
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 10).isActive = true
        titleLabel.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: 10).isActive = true
        titleLabel.topAnchor.constraint(equalTo: headerView.topAnchor).isActive = true
        titleLabel.bottomAnchor.constraint(equalTo: headerView.bottomAnchor).isActive = true
        
        return headerView
    }
    
    //MARK: EstimatedLabelHeight :-
    
    func estimatedLabelHeight(text: String, width: CGFloat, font: UIFont) -> CGFloat {
        
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: 30))
        label.numberOfLines = 0
        label.text = text

        let rectOfLabel = label.textRect(forBounds: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude), limitedToNumberOfLines: 0)
        let heightOfLabel = rectOfLabel.height

        return heightOfLabel
    }
    
}

//MARK: HorizontalInfinteScrollable + ScrollAtHorizontalEnd
extension ViewController: HorizontalInfinteScrollable{
    func scrollAtHorizontalEnd(_ rowIndex: Int) {
        
        viewModel.increasePhotosArray(rowIndex: rowIndex) {
            DispatchQueue.main.async {
                self.tableView.reloadData()
                debugPrint("Horizontal size increased")
            }
        }
    }
}
