//
//  CollectionTableViewCell.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import UIKit
import SDWebImage


//MARK: Protocol to handle infinite scrolling in horizontal direction
protocol HorizontalInfinteScrollable: AnyObject{
    // Called when horizontal scrolling reaches end
    func scrollAtHorizontalEnd(_ rowIndex: Int)
}


class CollectionTableViewCell: UITableViewCell {

    @IBOutlet weak private var collectionView: UICollectionView!
    
    private weak var delegate : HorizontalInfinteScrollable?
    
    private var photoArray: [PhotoModel]?

    private var rowIndex: Int?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
    }
    
//MARK: Configures the cell with photo data and delegate to handle infinite scrolling
    
    func config(data : [PhotoModel], delegate : HorizontalInfinteScrollable, rowIndex: Int){
        self.photoArray = data
        self.delegate = delegate
        self.rowIndex = rowIndex
        collectionView.reloadData()
    }
    
}

//MARK: UICollectionViewDelegate and UICollectionViewDataSource methods

extension CollectionTableViewCell: UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoArray?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionVC", for: indexPath) as? ImageCollectionVC {
            cell.config(photoArray?[indexPath.row])
            cell.clipsToBounds = true
            cell.layoutIfNeeded()
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 180, height: 180)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        guard
            let rowIndex = rowIndex,
            let photoArrayCount = photoArray?.count else {
            return
        }
        if indexPath.row == photoArrayCount - 1  {
            self.delegate?.scrollAtHorizontalEnd(rowIndex)
        }
    }
}
