//
//  ImageCollectionVC.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import UIKit

class ImageCollectionVC: UICollectionViewCell{
    
    @IBOutlet weak private var image: UIImageView!
    
    //MARK: Set Image From Url
    func config(_ data : PhotoModel?){
        image.setImageFromLink(data?.thumbnailUrl,contentMode: .scaleAspectFit)
    }
    
}
