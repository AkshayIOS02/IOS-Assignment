//
//  HomeViewModel.swift
//  iOSTest
//
//  Created by Akshay Sharma on 02/04/23.
//

import Foundation

class HomeViewModel: NSObject{
    
    private let utility = APIManager.shared
    
    var albumArr : [AlbumModel]?
    
//MARK: Album API Call
    func albumAPICall(completion : @escaping ()->Void){
        
        let requestUrl = Endponits.albums.url
        let request = Request(withUrl: requestUrl, forHttpMethod: .get)
        
        utility.request(request: request, resultType: [AlbumModel].self) { (response) in
            switch response{
            case .success(let album):
                guard let album = album else {
                    completion()
                    return
                }
                self.albumArr = album
                completion()
                
            case .failure(let error):
                print(error)
                completion()
                
            }
        }
    }

//MARK: GetPhotosForAlbum
    func getPhotosForAlbum(model : AlbumModel?,  completion: @escaping ([PhotoModel])->Void){
        if let existingPhotos = model?.albumPhotos, !existingPhotos.isEmpty{
            completion(existingPhotos)
            return
        }
        
        if model?.albumPhotos?.isEmpty ?? true{ // have to review this
            self.photoAPICall(id: model?.id ?? 0) { listPhotoModel in
                if let listPhotoModel = listPhotoModel {
                    model?.albumPhotos = listPhotoModel
                    completion(listPhotoModel)
                }
            }
        }
    }
    
//MARK: Photo API Call
    private func photoAPICall(id : Int, completion : @escaping ([PhotoModel]?)->Void){
        
        let requestUrl = Endponits.photoWith(id).url
        let request = Request(withUrl: requestUrl, forHttpMethod: .get)
        
        utility.request(request: request, resultType: [PhotoModel].self) { (response) in
            switch response{
            case .success(let photos):
                completion(photos)
                
            case .failure(let error):
                print(error)
                completion(nil)
                
            }
        }
    }
    
    //MARK: Increase Album Array
    func increaseAlbumArray(completion : ()-> Void){
        guard let albumArray = self.albumArr else {
            return
        }
        
        self.albumArr?.append(contentsOf: albumArray)
        completion()
        
    }
    //MARK: Increase Photo Array
    func increasePhotosArray(rowIndex: Int,completion : ()-> Void){
        guard
            let albumArrayCount = self.albumArr?.count,
            albumArrayCount > rowIndex,
            let photosModelList = self.albumArr?[rowIndex].albumPhotos
        else {
            return
        }
        
        self.albumArr?[rowIndex].albumPhotos?.append(contentsOf: photosModelList)
        completion()
    }
}
